package com.ensta.librarymanager.service;

import com.ensta.librarymanager.dao.*;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MembreServiceImpl implements MembreService{

    private static MembreServiceImpl instance = null;
    private MembreServiceImpl() { }
    public static MembreServiceImpl getInstance()
    {
        if(instance==null)
        {instance=new MembreServiceImpl();}
        return instance;
    }


    public List<Membre> getList() throws ServiceException{
        List<Membre> membres = new ArrayList<>();
        try {
            membres = MembreDaoImpl.getInstance().getlist();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return membres;
    }


    public  List<Membre> getListMembreEmpruntPossible() throws ServiceException{
        EmpruntServiceImpl empruntService=EmpruntServiceImpl.getInstance();
        List<Membre> membres = new ArrayList<>();
        try {
            membres = MembreDaoImpl.getInstance().getlist();
            for(Membre m:membres)
                if(empruntService.isEmpruntPossible(m)==false)
                    membres.remove(m);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return membres;
    }

    public Membre getById(int id) throws ServiceException{
        Membre membre=new Membre();
        try {
            membre = MembreDaoImpl.getInstance().getById(id);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return membre;
    }

    public int create(String nom, String prenom, String adresse, String email, String telephone) throws ServiceException{
        Membre membre = new Membre();
        int i = -1;
        try {
            if((nom!=null) && (prenom!=null))
                i = MembreDaoImpl.getInstance().create(nom.toUpperCase(),prenom, adresse, email, telephone);
        }  catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return i;
    }

    public void update(Membre membre) throws ServiceException{
        int i = -1;
        try {
            String nom=membre.getNom();
            String prenom=membre.getPrenom();
            if((nom!=null) && (prenom!=null)) {
                membre.setNom(nom.toUpperCase());
                MembreDaoImpl.getInstance().update(membre);
            }
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        } catch (NumberFormatException e2) {
            try {
                throw new ServiceException("Erreur lors du parsing: id=" + membre, e2);
            } catch (ServiceException e) {
                e.printStackTrace();
            }
        }
    }

    public void delete(int id) throws DaoException{
        try {
            Membre membre = MembreDaoImpl.getInstance().getById(id);
            MembreDaoImpl.getInstance().delete(id);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        } catch (NumberFormatException e2) {
            try {
                throw new ServiceException("Erreur lors du parsing: id=" + id, e2);
            } catch (ServiceException e) {
                e.printStackTrace();
            }
        }
    }

    public int count() throws DaoException{

        List<Membre> membres = new ArrayList<>();
        int i=0;
        try {
            i = MembreDaoImpl.getInstance().count();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return i;
    }
}
