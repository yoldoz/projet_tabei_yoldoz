package com.ensta.librarymanager.Test;

import com.ensta.librarymanager.dao.EmpruntDaoImpl;
import com.ensta.librarymanager.dao.LivreDaoImpl;
import com.ensta.librarymanager.dao.MembreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

import static java.time.LocalDate.of;

public class DaoTest {
    public static void main(String[] args)throws IOException, DaoException {
        EmpruntDaoImpl empruntDao= EmpruntDaoImpl.getInstance();
        LivreDaoImpl livreDao=LivreDaoImpl.getInstance();
        MembreDaoImpl membreDao=MembreDaoImpl.getInstance();

        Membre membre=new Membre();
        Livre livre=new Livre();
        Emprunt emprunt=new Emprunt();

        List<Livre> livres=new ArrayList<>();
        List<Emprunt> emprunts=new ArrayList<>();
        List<Membre> membres=new ArrayList<>();



        try{
                 int i=livreDao.create(" 1984 "," George Orwell "," abcd14 ");
                System.out.println(i);
        }
        catch (DaoException e)
        {
            e.getMessage();
        }

        try{
            emprunt=empruntDao.getById(30);
            System.out.println(membre.getPrenom());
        }catch(DaoException e){
            e.printStackTrace();
        }

        try{
            livres =livreDao.getlist();
        }catch(DaoException e){
            e.printStackTrace();
        }

    }
}

