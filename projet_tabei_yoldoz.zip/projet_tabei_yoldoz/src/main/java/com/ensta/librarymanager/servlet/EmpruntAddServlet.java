package com.ensta.librarymanager.servlet;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;
import com.ensta.librarymanager.service.*;

import java.io.IOException;
import javax.servlet.http.HttpServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public class EmpruntAddServlet extends HttpServlet {



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        showAllPossible(request, response);
    }

    private void showAllPossible(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EmpruntService empruntImplService = EmpruntServiceImpl.getInstance();

        MembreService membreImplService = MembreServiceImpl.getInstance();
        List<Membre> membres = new ArrayList<>();

        LivreService livreImplService = LivreServiceImpl.getInstance();
        List<Livre> livres = new ArrayList<>();
        try {
            livres = livreImplService.getListDispo();
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        request.setAttribute("Livres_dispo", livres);


        try {
            membres = membreImplService.getListMembreEmpruntPossible();
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        request.setAttribute("Membres_dispo", membres);


        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/emprunt_add.jsp");
        dispatcher.forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int idLivre = Integer.parseInt(request.getParameter("idLivre"));
        int idMembre = Integer.parseInt(request.getParameter("idMembre"));
        LocalDate dateRetour=LocalDate.parse(request.getParameter("dateRetour"))  ;
        LocalDate dateEmprunt=LocalDate.parse(request.getParameter("dateEmprunt"))  ;
        EmpruntService empruntImplService = EmpruntServiceImpl.getInstance();


    //    try {
            //empruntImplService.create(idLivre, idMembre, dateEmprunt, dateRetour);

    //    } catch (ServiceException e) {
       //     System.out.println(e.getMessage());
      //      e.printStackTrace();

     //   }
    }
}