package com.ensta.librarymanager.Test;

import com.ensta.librarymanager.dao.EmpruntDaoImpl;
import com.ensta.librarymanager.dao.LivreDaoImpl;
import com.ensta.librarymanager.dao.MembreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;

import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;

import com.ensta.librarymanager.service.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

import static java.time.LocalDate.of;

public class ServiceTest {

    public static void main(String[] args) throws IOException, DaoException {

        EmpruntServiceImpl empruntService= EmpruntServiceImpl.getInstance();
        MembreServiceImpl membreService=MembreServiceImpl.getInstance();
        LivreServiceImpl livreService=LivreServiceImpl.getInstance();

        List<Livre> livres=new ArrayList<>();
        List<Emprunt> emprunts=new ArrayList<>();
        List<Membre> membres=new ArrayList<>();

        try{
           int i=livreService.count();
        }catch(ServiceException e){
            e.printStackTrace();
        }

        try {
            livres=livreService.getList();
        } catch (ServiceException e) {
            e.printStackTrace();
        }


        try{
            int j=membreService.create("Clarcke", "Emily", "Paris", "emilyclarcke@gmail.com", "02589631470");
        }catch(ServiceException e){
            e.printStackTrace();
        }


        try {
            emprunts=empruntService.getListCurrentByLivre(2);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }
}
