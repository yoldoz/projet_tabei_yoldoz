package com.ensta.librarymanager.dao;

import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;
import com.ensta.librarymanager.persistence.ConnectionManager;

import javax.swing.plaf.basic.BasicTreeUI;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class EmpruntDaoImpl {

    private static EmpruntDaoImpl instance;
    private EmpruntDaoImpl() { }
    public static EmpruntDaoImpl getInstance() {
        if(instance == null) {
            instance = new EmpruntDaoImpl();
        }
        return instance;
    }

    private static final String SELECT_ALL_QUERY = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre SELECT e.id AS id, idMembre, nom, prenom, adresse, email,telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre ORDER BY dateRetour DESC;ORDER BY dateRetour DESC";
    private static final String SELECT_CURRENT_QUERY = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email,telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt,dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE dateRetour IS NULL;";
    private static final String SELECT_CURRENT_BY_MEMBRE_QUERY = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email,telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt,dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE dateRetour IS NULL AND membre.id = ?;";
    private static final String SELECT_CURRENT_BY_LIVRE_QUERY="SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE dateRetour IS NULL AND livre.id = ?;";
    private static final String SELECT_CURRENT_BY_ID_QUERY="SELECT e.id AS idEmprunt, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE e.id = ?;";
    private static final String CREATE_QUERY = "INSERT INTO emprunt(idMembre, idLivre, dateEmprunt, dateRetour) VALUES (?, ?, ?, ?);";
    private static final String UPDATE_QUERY = "UPDATE emprunt SET idMembre = ?, idLivre = ?, dateEmprunt = ?, dateRetour = ? WHERE id = ?;";
    private static final String COUNT_QUERY = "SELECT COUNT(id) AS count FROM emprunt;";



    public List<Emprunt> getList() throws DaoException {
        List<Emprunt> emprunts = new ArrayList<>();
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
            res = preparedStatement.executeQuery();
            while(res.next()) {
                Membre membre = new Membre(res.getInt("idMembre"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("email"), res.getString("telephone"), res.getString(("abonnement").toString()));
                Livre livre = new Livre(res.getInt("idLivre"), res.getString("titre"), res.getString("auteur"), res.getString("isbn"));
                LocalDate dateEmprunt;
                dateEmprunt = res.getDate("dateEmprunt").toLocalDate();
                LocalDate dateRetour= res.getDate("dateRetour").toLocalDate();
                Emprunt emprunt = new Emprunt(membre,livre,dateEmprunt,dateRetour);
                emprunts.add(emprunt);
            }
            System.out.println("GET: " + emprunts);
        } catch (SQLException e) {
            throw new DaoException("Probl�me lors de la r�cup�ration de la liste des emprunts", e);
        } finally {
            try {
                res.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return emprunts;
    }


    public List<Emprunt> getListCurrent() throws DaoException {
        List<Emprunt> emprunts = new ArrayList<>();
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int id=0;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_CURRENT_QUERY);
            res = preparedStatement.executeQuery();
            while(res.next()) {
                Membre membre = new Membre(res.getInt("idMembre"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("email"), res.getString("telephone"));
                Livre livre = new Livre(res.getInt("idLivre"), res.getString("titre"), res.getString("auteur"), res.getString("isbn"));
                LocalDate dateEmprunt=res.getDate("dateEmprunt").toLocalDate();
                LocalDate dateRetour=res.getDate("dateRetour").toLocalDate();
                LocalDate date=null;
                if(dateRetour==null)
                    date=res.getDate("dateRetour").toLocalDate();
                Emprunt emprunt=new Emprunt(id, membre, livre, dateEmprunt, dateRetour);
                emprunts.add(emprunt);
            }

            System.out.println("GET: " + emprunts);
        } catch (SQLException e) {
            throw new DaoException("Probl�me lors de la r�cup�ration de l'emprunt: id=" + id, e);
        } finally {
            try {
                res.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return emprunts;
    }

    public List<Emprunt> getListCurrentByMembre(int idMembre) throws ServiceException, DaoException {
        List<Emprunt> emprunts = new ArrayList<>();
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_CURRENT_QUERY);
            preparedStatement.setInt(1, idMembre);
            res = preparedStatement.executeQuery();
            while(res.next()) {
                LocalDate dateRetour=res.getDate("dateRetour").toLocalDate();
                LocalDate date=null;
                int i = res.getInt("idMembre");
                if((dateRetour==null)&&(i==idMembre)) //livre pas encore rendu
                {
                    date=res.getDate("dateRetour").toLocalDate();
                    Membre membre = new Membre(res.getInt("idMembre"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("email"), res.getString("telephone"));
                    Livre livre = new Livre(res.getInt("idLivre"), res.getString("titre"), res.getString("auteur"), res.getString("isbn"));
                    LocalDate dateEmprunt=res.getDate("dateEmprunt").toLocalDate();
                    Emprunt emprunt=new Emprunt(membre, livre, dateEmprunt,dateRetour);
                    emprunts.add(emprunt);
                }
            }

            System.out.println("GET: " + emprunts);
        } catch (SQLException e) {
            throw new DaoException("Probl�me lors de la r�cup�ration de l'emprunt: id=" + idMembre, e);
        } finally {
            try {
                res.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return emprunts;
    }

    public List<Emprunt> getListCurrentByLivre(int idLivre) throws DaoException {
        List<Emprunt> emprunts = new ArrayList<>();
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_CURRENT_QUERY);
            preparedStatement.setInt(1, idLivre);
            res = preparedStatement.executeQuery();
            while (res.next()) {
                LocalDate dateRetour = res.getDate("dateRetour").toLocalDate();
                LocalDate date = null;
                int i = res.getInt("idLivre");
                if ((dateRetour == null) && (i == idLivre)) //livre pas encore rendu
                {
                    date = res.getDate("dateRetour").toLocalDate();
                    Membre membre = new Membre(res.getInt("idMembre"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("email"), res.getString("telephone"));
                    Livre livre = new Livre(res.getInt("idLivre"), res.getString("titre"), res.getString("auteur"), res.getString("isbn"));
                    LocalDate dateEmprunt = res.getDate("dateEmprunt").toLocalDate();
                    Emprunt emprunt = new Emprunt(membre, livre, dateEmprunt, dateRetour);
                    emprunts.add(emprunt);
                }
            }

            System.out.println("GET: " + emprunts);
        } catch (SQLException e) {
            e.getMessage();
        } finally {

            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return emprunts;
    }

    public Emprunt getById(int id) throws DaoException{
        Emprunt emprunt=new Emprunt();
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
            preparedStatement.setInt(1, id);
            res = preparedStatement.executeQuery();
            if(res.next()){
                int m=res.getInt("id");
                Membre membre = new Membre(res.getInt("idMembre"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("email"), res.getString("telephone"));
                Livre livre = new Livre(res.getInt("idLivre"), res.getString("titre"), res.getString("auteur"), res.getString("isbn"));
                LocalDate dateEmprunt=res.getDate("dateEmprunt").toLocalDate();
                LocalDate dateRetour=res.getDate("dateRetour").toLocalDate();
                emprunt.setId(res.getInt("id"));
                emprunt.setMembre(membre);
                emprunt.setLivre(livre);
                emprunt.setDateEmprunt(dateEmprunt);
                emprunt.setDateRetour(dateRetour);
            }

            System.out.println("GET: "+ emprunt);
        } catch (SQLException e) {
           e.getMessage();
        } finally {

            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return emprunt;
    }


    public void create(int idMembre, int idLivre, LocalDate dateEmprunt) throws DaoException {
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int id = -1;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(CREATE_QUERY, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setInt(1, idMembre);
            preparedStatement.setInt(2, idLivre);
            preparedStatement.setString(3, dateEmprunt.toString());
            preparedStatement.executeUpdate();

            System.out.println("CREATE: ");
        } catch (SQLException e) {
            throw new DaoException("Probl�me lors de la cr�ation de l'emprunt ", e);
        } finally {
            try {
                if(res!=null){
                    res.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void update(Emprunt emprunt) throws DaoException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(UPDATE_QUERY);
            preparedStatement.setString(1, emprunt.getMembre().getNom());
            preparedStatement.setString(2, emprunt.getMembre().getPrenom());
            preparedStatement.setString(3, emprunt.getMembre().getAdresse());
            preparedStatement.setString(4, emprunt.getMembre().getEmail());
            preparedStatement.setString(5, emprunt.getMembre().getTelephone());
            preparedStatement.setString(6, emprunt.getLivre().getTitre());
            preparedStatement.setString(7, emprunt.getLivre().getAuteur());
            preparedStatement.setString(8, emprunt.getLivre().getIsbn());
            preparedStatement.setString(9, emprunt.getDateEmprunt().toString());
            preparedStatement.setString(10, emprunt.getDateRetour().toString());
            preparedStatement.executeUpdate();

            System.out.println("UPDATE: " + emprunt);
        } catch (SQLException e) {
            throw new DaoException("Probl�me lors de la mise � jour du livre: " + emprunt, e);
        } finally {
            try {
                preparedStatement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public int count() throws DaoException {
        List<Emprunt> emprunts = new ArrayList<>();
        ResultSet res = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int i=0;
        try {
            connection = ConnectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
            res = preparedStatement.executeQuery();
            while(res.next()) {
                Membre membre = new Membre(res.getInt("idMembre"), res.getString("nom"), res.getString("prenom"), res.getString("adresse"), res.getString("email"), res.getString("telephone"), res.getString(("abonnement").toString()));
                Livre livre = new Livre(res.getInt("idLivre"), res.getString("titre"), res.getString("auteur"), res.getString("isbn"));
                LocalDate dateEmprunt;
                dateEmprunt = res.getDate("dateEmprunt").toLocalDate();
                LocalDate dateRetour= res.getDate("dateRetour").toLocalDate();
                Emprunt emprunt = new Emprunt(membre,livre,dateEmprunt,dateRetour);
                emprunts.add(emprunt);
                i++;
            }
            System.out.println("GET: " + emprunts);
        } catch (SQLException e) {
            throw new DaoException("Probl�me lors de la r�cup�ration de la liste des emprunts", e);
        } finally {
            try {
                res.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return i;
    }
}
