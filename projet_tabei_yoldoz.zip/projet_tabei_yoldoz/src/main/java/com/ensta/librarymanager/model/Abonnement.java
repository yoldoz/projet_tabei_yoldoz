package com.ensta.librarymanager.model;

public enum Abonnement {
    BASIC("BASIC", 2), PREMIUM("PREMIUM", 5), VIP("VIP",20);

    private int val;
    private String s;

    Abonnement(String s, int i) {
        if(s.equals("Basic"))
            this.val=2;
        else if(s.equals("PREMIUM"))
            this.val=5;
        else if(s.equals("VIP"))
            this.val=20;
    }

    public void value(String s) {
        if(s.equals("Basic"))
            this.val=2;
        else if(s.equals("PREMIUM"))
            this.val=5;
        else if(s.equals("VIP"))
            this.val=20;
    }

    public void name(String abonnement) {
        this.s=abonnement;
        this.value(abonnement);

    }
}
