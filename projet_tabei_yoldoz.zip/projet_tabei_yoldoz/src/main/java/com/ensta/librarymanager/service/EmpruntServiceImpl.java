package com.ensta.librarymanager.service;

import com.ensta.librarymanager.dao.EmpruntDao;
import com.ensta.librarymanager.dao.EmpruntDaoImpl;
import com.ensta.librarymanager.dao.LivreDao;
import com.ensta.librarymanager.dao.LivreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class EmpruntServiceImpl implements EmpruntService{

    private static EmpruntServiceImpl instance = null;
    private EmpruntServiceImpl() { }
    public static EmpruntServiceImpl getInstance()
    {
        if(instance==null)
        {instance=new EmpruntServiceImpl();}
        return instance;
    }

    public List<Emprunt> getList() throws ServiceException{
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = EmpruntDaoImpl.getInstance().getList();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return emprunts;
    }

    public List<Emprunt> getListCurrent() throws ServiceException{
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = EmpruntDaoImpl.getInstance().getListCurrent();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return emprunts;
    }

    public List<Emprunt> getListCurrentByMembre(int idMembre) throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = empruntDao.getListCurrentByMembre(idMembre);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return emprunts;
    }

    public List<Emprunt> getListCurrentByLivre(int idLivre) throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = empruntDao.getListCurrentByLivre(idLivre);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return emprunts;
    }

    public Emprunt getById(int id) throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        Emprunt emprunt=new Emprunt();
        try {
            emprunt = EmpruntDaoImpl.getInstance().getById(id);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return emprunt;
    }

    public void create(int idMembre, int idLivre, LocalDate dateEmprunt) throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        Emprunt emprunt = new Emprunt();
        try {
            empruntDao.create(idMembre,  idLivre, dateEmprunt);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
    }

    public void returnBook(int id) throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        Emprunt emprunt= new Emprunt();
        try {
            emprunt=empruntDao.getById(id);
            emprunt.setDateRetour(LocalDate.now());
            empruntDao.update(emprunt);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
    }

    public int count() throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        int i=0;
        try {
            i = empruntDao.count();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return i;
    }

    public boolean isLivreDispo(int idLivre) throws ServiceException{
        List<Emprunt> emprunts = new ArrayList<>();
        boolean b=true;
        try {
            emprunts = EmpruntDaoImpl.getInstance().getListCurrentByLivre(idLivre);
            int s=emprunts.size();
            if (s==0)
                b=false;
            } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return b;
    }

    public boolean isEmpruntPossible(Membre membre) throws ServiceException{
        EmpruntDaoImpl empruntDao = EmpruntDaoImpl.getInstance();
        Emprunt emprunt= new Emprunt();
        List<Emprunt> emprunts=new ArrayList<>();
        boolean b=false;
        try {

            int idMembre=membre.getId();
            emprunts=EmpruntDaoImpl.getInstance().getListCurrentByMembre(idMembre);
            int s=emprunts.size();
            if((membre.getAbonnement().toString()=="BASIC") && s<2)
                b=true;
            else if((membre.getAbonnement().toString()=="PREMIUM") && s<5)
                b=true;
            else if((membre.getAbonnement().toString()=="VIP") && s<20)
                b=true;

        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return b;
    }

}
