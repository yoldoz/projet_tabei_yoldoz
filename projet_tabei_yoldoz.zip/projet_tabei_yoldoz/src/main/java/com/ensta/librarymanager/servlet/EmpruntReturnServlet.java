package com.ensta.librarymanager.servlet;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;
import com.ensta.librarymanager.service.*;

import java.io.IOException;
import javax.servlet.http.HttpServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public class EmpruntReturnServlet extends HttpServlet {



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String action = request.getServletPath();
        if (action.equals("/emprunt_return"))
            emprunt_return(request, response);
    }

    private void emprunt_return(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EmpruntService empruntImplService = EmpruntServiceImpl.getInstance();

        String Id = request.getParameter("idLivre");
        int inputId=Integer.parseInt(Id);

        MembreService membreImplService = MembreServiceImpl.getInstance();
        List<Membre> membres = new ArrayList<>();

        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = empruntImplService.getList();
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        request.setAttribute("emprunts_actuels", emprunts);


        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/emprunt_return.jsp");
        dispatcher.forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);;
    }
}