package com.ensta.librarymanager.Test;

import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.model.*;
import java.time.LocalDate;

import java.io.IOException;

public class ModelTest {

    public static void main(String[] args) throws IOException, DaoException {
        Livre livre=new Livre("1984","George Orwell","abcd14");
        Membre membre=new Membre("Smith","Sandra","Résidence MANCEAU Palaiseau","sandrasmith@gmail.com","01236549870");
        Emprunt emprunt=new Emprunt(membre,livre,LocalDate.of(2020,5,1),LocalDate.of(2020,6,1));

        String nom1=membre.getNom();
        livre.setIsbn("abcd12");
        emprunt.setDateRetour(LocalDate.of(2020,5,31));
        System.out.println("-----MEMBRE-----");
        String s1=membre.toString();
        System.out.println(s1);
        System.out.println("-----LIVRE-----");
        String s2=livre.toString();
        System.out.println(s2);
        System.out.println("-----EMPRUNT-----");
        String s3=emprunt.toString();
        System.out.println(s3);
    }
}
