package com.ensta.librarymanager.service;

import com.ensta.librarymanager.dao.EmpruntDaoImpl;
import com.ensta.librarymanager.dao.LivreDao;
import com.ensta.librarymanager.dao.LivreDaoImpl;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;


import java.util.ArrayList;
import java.util.List;

public class LivreServiceImpl implements LivreService{


    private static LivreServiceImpl instance = null;
    private LivreServiceImpl() { }
    public static LivreServiceImpl getInstance()
    {
        if(instance==null)
        {instance=new LivreServiceImpl();}
        return instance;
    }

    public List<Livre> getList() throws ServiceException{
        List<Livre> livres = new ArrayList<>();
        try {
            livres = LivreDaoImpl.getInstance().getlist();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return livres;
    }

    public List<Livre> getListDispo() throws ServiceException{
        LivreDaoImpl livreDao=LivreDaoImpl.getInstance();
        EmpruntServiceImpl empruntService= EmpruntServiceImpl.getInstance();
        List<Livre> livres= new ArrayList<>();
        List<Livre> livres_dispo= new ArrayList<>();
        List<Emprunt> emprunts=new ArrayList<>();
        try {
            livres=livreDao.getlist();
            for(Livre l:livres){
                if(empruntService.isLivreDispo(l.getId()))
                    livres_dispo.add(l);
            }
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return livres_dispo;
    }

    public Livre getById(int id) throws ServiceException {
        Livre livre=new Livre();
        try {
            livre = LivreDaoImpl.getInstance().getById(id);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return livre;
    }


    public int create(String titre, String auteur, String isbn) throws ServiceException {
        Livre livre = new Livre();
        int i = -1;
        if(titre==null)
            throw new ServiceException();
        try {
                i = LivreDaoImpl.getInstance().create(titre, auteur, isbn);
        }  catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return i;
    }


    public void update(Livre livre) throws ServiceException {
        try {
            int id =livre.getId();
            String titre=livre.getTitre();
            String auteur=livre.getAuteur();
            String isbn=livre.getIsbn();
            if(titre!=null) {
                livre = new Livre(id, titre, auteur, isbn);
                LivreDaoImpl.getInstance().update(livre);
            }
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        } catch (NumberFormatException e2) {
            throw new ServiceException("Erreur lors du parsing: id=" + livre, e2);
        }
    }


    public void delete(int id) throws ServiceException {
        int i = -1;
        try {
            Livre livre = LivreDaoImpl.getInstance().getById(id);
            LivreDaoImpl.getInstance().delete(id);
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        } catch (NumberFormatException e2) {
            throw new ServiceException("Erreur lors du parsing: id=" + id, e2);
        }
    }

    public int count() throws ServiceException {

        List<Livre> livres = new ArrayList<>();
        int i=0;
        try {
            i = LivreDaoImpl.getInstance().count();
        } catch (DaoException e1) {
            System.out.println(e1.getMessage());
        }
        return i;
    }

}
